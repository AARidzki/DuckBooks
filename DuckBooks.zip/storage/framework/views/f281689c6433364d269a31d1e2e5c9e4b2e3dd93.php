
dd()
<?php $__env->startSection('container'); ?>
    <h1 class="mb-3">Buku Rekomendasi</h1>

    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-3">
                    
                    <div class="card" style="width: 12em; ">
                        <img src="<?php echo e(asset('storage/' . $book->image)); ?>" class="card-img-top" alt="<?php echo e($book->tittle); ?>"
                                                class="img-fluid ">
                        <div class="card-body">
                            <h5 class="card-title"><a href="/books/<?php echo e($book['slug']); ?>"><?php echo e($book['tittle']); ?></a></h5>
                            <p class="card-text"><?php echo e($book['pengarang']); ?></p>
                            <br>
                            <small class="card-text">Rp <?php echo e($book['harga']); ?></small>

                        </div>
                    </div>
                
                        
<!-- CODE SEBELUMNYA -->

<p></p>

<!-- TAMBAHKAN FORM ACTION -->
<form action="<?php echo e(route('front.cart')); ?>" method="POST">
  <?php echo csrf_field(); ?>
  <div class="product_count">
    <label for="qty">Quantity:</label>
    <input type="text" name="qty" id="sst" maxlength="12" value="1" title="Quantity:" class="input-text qty">
    
    <!-- BUAT INPUTAN HIDDEN YANG BERISI ID PRODUK -->
    <input type="hidden" name="id" value="<?php echo e($book['id']); ?>" class="form-control">
    

      <i class="lnr lnr-chevron-down"></i>
    </button>
  </div>
  <div class="card_area">
    
    <!-- UBAH JADI BUTTON -->
    <button class="main_btn">Add to Cart</button>
    <!-- UBAH JADI BUTTON -->
    
  </div>
</form>

<!-- CODE SETELAHNYA -->


            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\DuckBooks\resources\views/books.blade.php ENDPATH**/ ?>