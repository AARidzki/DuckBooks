@extends('layouts.main')

@section('container')
    
    <h1>Halaman About</h1>
    <br>
    <h3>{{ $nama }}</h3>
    <p>{{ $email }}</p>
    <img src="img/nurul1.JPG" alt="uyun.jpg" width="200">

@endsection