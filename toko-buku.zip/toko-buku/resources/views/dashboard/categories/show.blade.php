@extends('dashboard.layouts.main')

@section('container')
    <h1>belum ada ide ini halaman mau digimanain</h1>
@endsection