

@extends('layouts.main')

@section('container')

    {{-- @foreach ($books as $book)
        <h2>{{ $book["tittle"] }}</h2>
        <h5>{{ $book["penulis"] }}</h5>
    @endforeach --}}
    
@endsection